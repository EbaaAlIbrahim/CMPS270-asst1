#include <stdio.h>
#include <stdlib.h>
#include <math.h>
//#define _countof(array)(sizeof(array)/sizeof(array[0]))

int *decToBinary(int);
int msb(int *);
int lsb(int *);
int main()
{
    int binaryarr1[32];
    int *pBinArray;
    int number;
    int n = -1;
    int msb1,lsb1;
    while (n < 0)
    {
        printf("please enter a positive integer number\n");
        scanf("%d", &number);
        if (number > 0)
        {
            pBinArray = decToBinary(number);
            msb1 = msb(pBinArray);
            printf("%d\n",msb1);
            lsb1 = lsb(pBinArray);
            printf("%d\n",lsb1);
            while (*pBinArray == 0 || *pBinArray ==1)
            {
                printf("%d", *pBinArray);
                pBinArray++;
            }
            printf("\n%d\n",abs(msb1-lsb1));
            system("pause");
            return 0;
        }
        else
            printf("Wrong you entered a negative number please engter a positive number\n");
    }
}

int *decToBinary(int number)
{

    int binaryarr[32];
    int i = 0;
    int k = 0;
    int counter = 0;
    int *b = (int *)malloc(sizeof(int) * 32);
    while (number > 0)
    {
        binaryarr[i] = number % 2;
        number = number / 2;
        i++;
    }
    for (int j = i - 1; j >= 0; j--)
    {
        b[k] = binaryarr[j];
        k++;
        counter++;
    }
    return b;
}
int msb(int *p){
    int count = 0;
    while(*p!=1){
        count++;
    }
    return count;
}
int lsb(int *p){
    int count =0;
    while(*p==0 || *p==1){
        count++;
        p++;
    }
    while(*p!=1){
        count--;
        p--;
    }
    return count;
}