#include<stdio.h>
#include<stdlib.h>

int main(){

    int user_enter1;
    int user_enter2;

    int absolute;
    printf("please enter the two numbers number\n");
    scanf("%d",&user_enter1);
    if(user_enter1 < 0)
    return 0;
    scanf("%d",&user_enter2);
    if(user_enter2 < 0)
    return 0;

    while(user_enter1 >=0 && user_enter2 >=0){
        absolute = abs(user_enter1-user_enter2);
        if(absolute == 0 && absolute ==1)
        printf("%d",1);
        else
        printf("%d",absolute-1);
        if(user_enter1 < 0)
        return 0;
        scanf("%d",&user_enter2);
        if(user_enter2 < 0)
        return 0;
    }
    return 0;
}