#include <stdio.h>
#include <stdlib.h>

int main()
{
    int user_enter1, user_enter2;
    int absolute;
    printf("please enter two positive integers\n");
    scanf("%d", &user_enter1);
    if (user_enter1 < 0)
    {
        system("pause");
        return 0;
    }
    scanf("%d", &user_enter2);
    if (user_enter2 < 0)
    {
        system("pause");
        return 0;
    }
    while (user_enter1 >= 0 && user_enter2 >= 0)
    {
        absolute = abs(user_enter1 - user_enter2);
        if (absolute == 1)
            printf("%d\n", 1);
        else if(absolute == 0)
            printf("%d\n",0);
        else
            printf("%d\n", abs(user_enter1 - user_enter2) - 1);
        printf("please enter two positive integers\n");
        scanf("%d", &user_enter1);
        if (user_enter1 < 0)
        {
           system("pause");
            return 0;
        }
        scanf("%d", &user_enter2);
        if (user_enter2 < 0)
        {
           system("pause");
            return 0;
        }
    }
}