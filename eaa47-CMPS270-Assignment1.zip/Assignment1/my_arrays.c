#include<stdio.h>
#include<stdlib.h>
void printArray(int [],int);
void arrayHistogram(int [], int);
void swapValues(int [],int , int , int );
void bubbleSort(int [],int );
int median(int [],int );
void mode(int [],int );
int isSorted(int [],int );

int main(){

    const int SIZE = 10;
    int array[10];
    printf("please enter numbers either 1 or 2 or 3\n");
    for(int i=0;i<SIZE;i++){
        scanf("%d",&array[i]);
    }
    printArray(array, SIZE);
    arrayHistogram(array, SIZE);
    swapValues(array,SIZE, 3, 4);
    bubbleSort(array,SIZE);
    median(array,SIZE);
    mode(array,SIZE);
    isSorted(array,SIZE);

    system("pause");
    return 0;
}
void printArray(int array[],int SIZE){

   printf("%s %9s\n","Index","Value");
   for (int i = 0; i < SIZE; i++)
      printf("%5u %9d\n", i, array[i]);

}
void arrayHistogram(int array[], int SIZE){

    int frequency=1;
    int j;
   char star[10];
   for(j=0;j<SIZE;j++){
    star[j]='\0';
   }
    printf("%s %9s %5s\n","Value","Frequency","Histogram");
    for (int i = 0; i < SIZE; i++){
        if(array[i] == array[i+1]){
        frequency++;
        j++;
        }
        else{
            j=0;
            while(j<frequency){
                star[j]='*';
                j++;
            }
            printf("%5d %9u %9s\n", array[i], frequency,star);
            j=0;
            while(j<SIZE){
                star[j]='\0';
                j++;
            }
            frequency=1;
        }

    }
}
void swapValues(int a[],int SIZE, int i, int j){

    int temp;
    temp=a[i];
    a[i]=a[j];
    a[j]=temp;
}
void bubbleSort(int a[],int SIZE){

    int i,j;
    for(i=SIZE-1;i>=0;i--){
        for(j=1;j<=i-1;j++){
            if(a[j]>a[j+1])
            swapValues(a,SIZE,j,j+1);
        }
    }
}
int median(int a[],int SIZE){

    int medal;
    int m;
    bubbleSort(a,SIZE);
    medal=SIZE/2;
    m = a[medal];
    return m;
}
void mode(int a[],int SIZE){

    int max=-1;
    int count=1;
    for(int i=0;i<SIZE;i++){
        if(a[i]==a[i+1])
        count++;
        else{
            if(count>max)
            max=count;
            count=1;
        }
    }
    printf("the mode is :%d\n",max);
}
int isSorted(int a[],int SIZE){
    int count = 1;
    for(int i=0;i<SIZE;i++){
        if(a[i]<=a[i+1])
        count++;
    }
    if(count == SIZE)
    return 1;
    else
     return 0;
}