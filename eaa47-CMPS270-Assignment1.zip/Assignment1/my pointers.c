#include <stdio.h>
#include <stdlib.h>
#include <math.h>

void merge(char **, char **, int, int);
int main()
{

    char *string1[] = {"ab", "ac"};
    char *string2[] = {"za", "zb", "zzzzc"};
    merge(string1, string2, 2, 3);
    return 0;
}

void merge(char **string1, char **string2, int size1, int size2)
{

    char **a;
    char *b;
    char *c;
    int size = size1 + size2;
    int i;
    int j;

    a = (char **)malloc(sizeof(char *) * size);
    b = (char *)malloc(sizeof(char) * size1);
    c = (char *)malloc(sizeof(char) * size2);

    for (i = 0; i < size; i++)
    {
        if (strlen(string1[i]) >= strlen(string2[i]))
        {
            a[i] = (char *)malloc(sizeof(char) * (strlen(string1[i]) + 1));
           j=0;
            while(j <= (strlen(a[i])))
                if (string1[i][j] < string2[i][j])
                {
                    for (int k = 0; i < size; i++)
                    {
                        a[k] = string1[k];
                        j++;
                    }
                }
                else if (string1[i][j] > string2[i][j])
                {
                    for (int k = 0; i < size; i++)
                    {
                        a[k] = string2[k];
                        j++;
                    }
                }
                else
                {
                    j++;
                }
        }
        else
        {
            a[i] = (char *)malloc(sizeof(char) * (strlen(string2[i]) + 1));
            j=0;
            while(j <=(strlen(a[i]))+1)
                if (string1[i][j] < string2[i][j])
                {
                    for (int k = 0; i < size; i++)
                    {
                        a[k] = string1[k];
                        j++;
                    }
                }
                else if (string1[i][j] > string2[i][j])
                {
                    for (int k = 0; i < size; i++)
                    {
                        a[k] = string2[k];
                        j++;
                    }
                }
                else
                {
                    j++;
                }
        }
        for (int i = 0; i < size; i++)
        {
            printf("%s", a[i]);
        }
    }
}